#include "pageTable.h"

#ifndef ALGORITHMS_H
#define ALGORITHMS_H


void FIFO (PAGETABLE* table, PAGE pageNum, int* firstIn);

#endif