//// Fran, Perry, Nick
//// Fall 2019
//// CS3074 Project 4
//// FILE:Page.h
//// Defines a PAGE as an integer (for simplicity of the program)

#ifndef PAGE_H
#define PAGE_H

typedef int PAGE;

#endif
