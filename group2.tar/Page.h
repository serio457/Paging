#ifndef PAGE_H
#define PAGE_H

typedef int PAGE;

#endif
